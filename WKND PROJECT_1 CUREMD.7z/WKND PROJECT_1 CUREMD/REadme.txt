- Make a Data Folder and make newe class IssueDBContext or maybe StudentDBContext

- Download packages required

- update config strig DB

- When make new controller for Coursescontroller, use API not MVC

- make a class for course as well

- Update the student.cs class



- Test on Postman

- Make GoogleDOCs reports

- Save separate query and Sql files,


- When CourseID is null, the web api gives an error

- When updating and adding student, why is ID required in request?